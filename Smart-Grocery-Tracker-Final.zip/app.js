// ============================================================================
// SMART GROCERY & BUDGET SAFETY TRACKER - APPLICATION CORE LOGIC
// Memenuhi Lengkap Seluruh Skenario Uji 1 s/d 9 (SRS F-01 s/d F-06B, UX & PWA)
// ============================================================================

import { 
  listenToShoppingSession, 
  saveSessionData, 
  getBackupFromLocalStorage,
  createDefaultSessionData,
  saveCustomFirebaseConfig,
  activeFirebaseConfig,
  isConfigPlaceholder
} from "./firebase-config.js";

// ============================================================================
// MARKET REFERENCE DATABASE FOR PRICE FLUCTUATION & RADAR (SRS F-04)
// Standar indeks harga pasar supermarket Jakarta / Bodetabek untuk anak rantau
// ============================================================================
const MARKET_PRICE_DATABASE = {
  "beras": {
    baseName: "Beras Ramos 5kg",
    unit: "sak",
    "Lotte Mart Grocery - Puri Indah": 72500,
    "Super Indo Intercon": 74900,
    "Indomaret Fresh - Meruya": 77000,
    "Hypermart - Puri Indah": 73500,
    "Transmart - Central Park": 76500,
    "Grand Lucky - Radio Dalam": 79000,
    avg: 75560
  },
  "telur": {
    baseName: "Telur Ayam 1kg",
    unit: "kg",
    "Lotte Mart Grocery - Puri Indah": 29000,
    "Super Indo Intercon": 27500, // Promo Super Indo
    "Indomaret Fresh - Meruya": 30000,
    "Hypermart - Puri Indah": 28500,
    "Transmart - Central Park": 29500,
    "Grand Lucky - Radio Dalam": 32000,
    avg: 29410
  },
  "minyak": {
    baseName: "Minyak Goreng 2L",
    unit: "pack",
    "Lotte Mart Grocery - Puri Indah": 33500, // Lotte Mart termurah
    "Super Indo Intercon": 34900,
    "Indomaret Fresh - Meruya": 37000,
    "Hypermart - Puri Indah": 34500,
    "Transmart - Central Park": 36000,
    "Grand Lucky - Radio Dalam": 38500,
    avg: 35730
  },
  "mie": {
    baseName: "Indomie Dus (Isi 40)",
    unit: "dus",
    "Lotte Mart Grocery - Puri Indah": 114000,
    "Super Indo Intercon": 116500,
    "Indomaret Fresh - Meruya": 122000,
    "Hypermart - Puri Indah": 115000,
    "Transmart - Central Park": 118000,
    "Grand Lucky - Radio Dalam": 125000,
    avg: 118410
  },
  "sabun": {
    baseName: "Sabun Mandi Refill 450ml",
    unit: "pack",
    "Lotte Mart Grocery - Puri Indah": 24500,
    "Super Indo Intercon": 22000,
    "Indomaret Fresh - Meruya": 26500,
    "Hypermart - Puri Indah": 20000, // Promo Hypermart
    "Transmart - Central Park": 25000,
    "Grand Lucky - Radio Dalam": 28000,
    avg: 24330
  },
  "susu": {
    baseName: "Susu UHT 1L",
    unit: "botol",
    "Lotte Mart Grocery - Puri Indah": 19000,
    "Super Indo Intercon": 19500,
    "Indomaret Fresh - Meruya": 21000,
    "Hypermart - Puri Indah": 18500,
    "Transmart - Central Park": 20000,
    "Grand Lucky - Radio Dalam": 23000,
    avg: 20160
  },
  "gula": {
    baseName: "Gula Pasir 1kg",
    unit: "kg",
    "Lotte Mart Grocery - Puri Indah": 17500,
    "Super Indo Intercon": 17500,
    "Indomaret Fresh - Meruya": 18000,
    "Hypermart - Puri Indah": 17500,
    "Transmart - Central Park": 17800,
    "Grand Lucky - Radio Dalam": 19500,
    avg: 17960
  }
};

// ============================================================================
// STATE APLIKASI UTAMA
// ============================================================================
const state = {
  sessionId: localStorage.getItem("active_grocery_session_id") || "sesi-lotte-mart-puri",
  storeLocation: "Lotte Mart Grocery - Puri Indah",
  shoppingDate: new Date().toISOString().split("T")[0],
  walletLimit: 500000,
  items: [],
  totalSpent: 0,
  totalSavings: 0,
  activeCategory: "ALL",
  activeTab: "paneBelanja",
  customStores: JSON.parse(localStorage.getItem("custom_stores_list") || "[]")
};

// ============================================================================
// AUDIO & HAPTIC FEEDBACK (100% OFFLINE WEB AUDIO & VIBRATION API - SRS F-08)
// ============================================================================
let audioCtx = null;

function getAudioContext() {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) audioCtx = new AudioContextClass();
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

function triggerHaptic(pattern = [25]) {
  if ("vibrate" in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch (e) {}
  }
}

// Suara "Ting" halus saat item ditambahkan / digandakan / dicentang
function playCartSound() {
  triggerHaptic([30]);
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12); // A5
    gain.gain.setValueAtTime(0.12, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.28);
  } catch (e) {}
}

// Suara "Double Pop" untuk penggandaan kuantitas tanpa delay (SRS F-02)
function playDuplicateSound() {
  triggerHaptic([20, 40, 30]);
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(659.25, ctx.currentTime); // E5
    osc.frequency.setValueAtTime(987.77, ctx.currentTime + 0.08); // B5
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.22);
  } catch (e) {}
}

// Suara "Warning Buzz" saat overbudget (SRS F-05)
function playOverbudgetAlarm() {
  triggerHaptic([180, 80, 180, 80, 250]);
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(220, ctx.currentTime);
    osc.frequency.setValueAtTime(196, ctx.currentTime + 0.12);
    gain.gain.setValueAtTime(0.22, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.4);
  } catch (e) {}
}

// ============================================================================
// FLOATING TOAST NOTIFICATION SYSTEM (SRS F-08)
// ============================================================================
function showToast(message, type = "info") {
  const container = document.getElementById("toastContainer");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast-message ${type}`;

  const iconMap = {
    success: "✓",
    warning: "⚠️",
    danger: "🚨",
    info: "ℹ️"
  };

  toast.innerHTML = `<span>${iconMap[type] || "•"}</span> <span>${escapeHtml(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    if (toast.parentNode) {
      toast.parentNode.removeChild(toast);
    }
  }, 2500);
}

// ============================================================================
// FORMATTERS & FORMULA DISKON BERTINGKAT KOMPOUND (SRS F-03)
// ============================================================================
function formatRupiah(number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  }).format(number || 0);
}

/**
 * Formula Perhitungan Diskon Bertingkat Kompound Supermarket (SRS F-03):
 * - Tier 1: disc1% dari basePrice
 * - Tier 2 Kompound: disc2% dari (basePrice - potongan Tier 1)
 * - Potongan Nominal Kasir: discNominal
 * - Final Price per unit = Max(0, After Tier 2 - discNominal)
 */
export function calculateCompoundPrice(basePrice, disc1 = 0, disc2 = 0, discNominal = 0) {
  const base = Math.max(0, Number(basePrice) || 0);
  const d1 = Math.min(100, Math.max(0, Number(disc1) || 0));
  const d2 = Math.min(100, Math.max(0, Number(disc2) || 0));
  const nom = Math.max(0, Number(discNominal) || 0);

  // Potongan Tier 1
  const afterTier1 = base * (1 - (d1 / 100));
  // Potongan Tier 2 (Kompound atas sisa harga setelah Tier 1)
  const afterTier2 = afterTier1 * (1 - (d2 / 100));
  // Potongan Kupon Kasir
  const netUnitPrice = Math.max(0, Math.round(afterTier2 - nom));
  const totalUnitSavings = Math.max(0, base - netUnitPrice);
  const effectivePercent = base > 0 ? Math.round((totalUnitSavings / base) * 100) : 0;

  return {
    basePrice: base,
    disc1: d1,
    disc2: d2,
    discNominal: nom,
    netUnitPrice: netUnitPrice,
    totalUnitSavings: totalUnitSavings,
    effectivePercent: effectivePercent
  };
}

// ============================================================================
// DOM ELEMENTS SELECTION
// ============================================================================
const elements = {
  storeSelector: document.getElementById("storeSelector"),
  shoppingDateInput: document.getElementById("shoppingDateInput"),
  syncBadgeBtn: document.getElementById("syncBadgeBtn"),
  syncStatusLabel: document.getElementById("syncStatusLabel"),
  
  // Budget Safety Card
  budgetSafetyCard: document.getElementById("budgetSafetyCard"),
  displayTotalSpent: document.getElementById("displayTotalSpent"),
  displayWalletLimit: document.getElementById("displayWalletLimit"),
  openBudgetLimitBtn: document.getElementById("openBudgetLimitBtn"),
  budgetProgressFill: document.getElementById("budgetProgressFill"),
  displayRemaining: document.getElementById("displayRemaining"),
  remainingVal: document.getElementById("remainingVal"),
  spentPercent: document.getElementById("spentPercent"),
  budgetStatusPill: document.getElementById("budgetStatusPill"),
  overbudgetAlert: document.getElementById("overbudgetAlert"),
  budgetSavingsContainer: document.getElementById("budgetSavingsContainer"),
  displayTotalDiscountSavings: document.getElementById("displayTotalDiscountSavings"),
  budgetAdvisorBox: document.getElementById("budgetAdvisorBox"),
  advisorTitle: document.getElementById("advisorTitle"),
  advisorText: document.getElementById("advisorText"),
  advisorActionArea: document.getElementById("advisorActionArea"),

  // Items List
  groceryItemList: document.getElementById("groceryItemList"),
  itemSummaryCount: document.getElementById("itemSummaryCount"),
  countInCart: document.getElementById("countInCart"),
  countTotal: document.getElementById("countTotal"),
  catChipsContainer: document.getElementById("catChipsContainer"),
  openAddItemModalBtn: document.getElementById("openAddItemModalBtn"),

  // Tabs & Nav
  bottomNavBar: document.getElementById("bottomNavBar"),
  paneBelanja: document.getElementById("paneBelanja"),
  paneRiwayat: document.getElementById("paneRiwayat"),
  paneAnggaran: document.getElementById("paneAnggaran"),
  categoryBreakdownList: document.getElementById("categoryBreakdownList"),
  historyListContainer: document.getElementById("historyListContainer"),
  saveSessionToHistoryBtn: document.getElementById("saveSessionToHistoryBtn"),
  storeComparisonTable: document.getElementById("storeComparisonTable"),
  bestDealAlert: document.getElementById("bestDealAlert"),

  // Budget Settings Tab
  inputWalletLimitSettings: document.getElementById("inputWalletLimitSettings"),
  btnSaveLimitSettings: document.getElementById("btnSaveLimitSettings"),

  // Local Persistence Test Panel (SRS F-06A)
  persistenceStatusBar: document.getElementById("persistenceStatusBar"),
  persistenceInfoText: document.getElementById("persistenceInfoText"),
  btnTestReloadSimulation: document.getElementById("btnTestReloadSimulation"),
  btnExportJsonBackup: document.getElementById("btnExportJsonBackup"),
  btnImportJsonTrigger: document.getElementById("btnImportJsonTrigger"),
  inputJsonFile: document.getElementById("inputJsonFile"),
  btnResetToDefaultDemo: document.getElementById("btnResetToDefaultDemo"),

  // Item Modal & Form
  itemModalOverlay: document.getElementById("itemModalOverlay"),
  closeItemModalBtn: document.getElementById("closeItemModalBtn"),
  itemForm: document.getElementById("itemForm"),
  editItemId: document.getElementById("editItemId"),
  modalTitle: document.getElementById("modalTitle"),
  inputItemName: document.getElementById("inputItemName"),
  quickItemSuggestions: document.getElementById("quickItemSuggestions"),
  inputItemCategory: document.getElementById("inputItemCategory"),
  inputItemUnit: document.getElementById("inputItemUnit"),
  inputItemPrice: document.getElementById("inputItemPrice"),
  inputItemQty: document.getElementById("inputItemQty"),
  inputItemNotes: document.getElementById("inputItemNotes"),

  // Compound Discount Form Fields (SRS F-03)
  inputDisc1: document.getElementById("inputDisc1"),
  inputDisc2: document.getElementById("inputDisc2"),
  inputDiscNominal: document.getElementById("inputDiscNominal"),
  calcBasePriceDisplay: document.getElementById("calcBasePriceDisplay"),
  calcDiscountSavingsDisplay: document.getElementById("calcDiscountSavingsDisplay"),
  calcNetPriceDisplay: document.getElementById("calcNetPriceDisplay"),

  // Custom Store Modal (SRS F-01)
  customStoreModalOverlay: document.getElementById("customStoreModalOverlay"),
  closeCustomStoreModalBtn: document.getElementById("closeCustomStoreModalBtn"),
  inputNewStoreName: document.getElementById("inputNewStoreName"),
  btnSaveCustomStore: document.getElementById("btnSaveCustomStore"),

  // Sync Modal (SRS F-06B)
  syncModalOverlay: document.getElementById("syncModalOverlay"),
  closeSyncModalBtn: document.getElementById("closeSyncModalBtn"),
  inputSessionId: document.getElementById("inputSessionId"),
  syncDetailsBox: document.getElementById("syncDetailsBox"),
  syncActivityLog: document.getElementById("syncActivityLog"),
  inputCustomFirebaseJson: document.getElementById("inputCustomFirebaseJson"),
  btnApplySessionSettings: document.getElementById("btnApplySessionSettings"),
  btnLaunchCompanionWindow: document.getElementById("btnLaunchCompanionWindow")
};

// ============================================================================
// KALKULASI & LOGIKA ANGGARAN (BUDGET SAFETY & ADVISOR - SRS F-05)
// ============================================================================
function calculateBudgetSafety() {
  let totalNet = 0;
  let totalGross = 0;
  let checkedTotal = 0;

  state.items.forEach(item => {
    const netUnitPrice = Number(item.price) || 0;
    const baseUnitPrice = Number(item.basePrice) || netUnitPrice;
    const qty = Number(item.qty) || 1;

    const subtotal = netUnitPrice * qty;
    const grossSubtotal = baseUnitPrice * qty;

    totalNet += subtotal;
    totalGross += grossSubtotal;

    if (item.isChecked) {
      checkedTotal += subtotal;
    }
  });

  state.totalSpent = totalNet;
  state.totalSavings = Math.max(0, totalGross - totalNet);

  const limit = state.walletLimit || 500000;
  const percentage = limit > 0 ? (totalNet / limit) * 100 : 0;
  const remaining = limit - totalNet;

  // Update UI Elements
  elements.displayTotalSpent.innerText = formatRupiah(totalNet);
  elements.displayWalletLimit.innerText = formatRupiah(limit);
  elements.remainingVal.innerText = formatRupiah(remaining);
  elements.spentPercent.innerText = `${Math.round(percentage)}%`;

  // Savings Badge (SRS F-03)
  if (state.totalSavings > 0) {
    elements.budgetSavingsContainer.style.display = "inline-flex";
    elements.displayTotalDiscountSavings.innerText = formatRupiah(state.totalSavings);
  } else {
    elements.budgetSavingsContainer.style.display = "none";
  }

  // Progress Bar Width
  const visualWidth = Math.min(percentage, 100);
  elements.budgetProgressFill.style.width = `${visualWidth}%`;

  // Status Indikator Multi-Tier:
  // Hijau (<75%), Kuning (75%-89%), Oranye/Kritis (90%-99%), Merah (>=100%)
  elements.budgetSafetyCard.classList.remove("safe", "warning", "danger");
  elements.budgetAdvisorBox.style.display = "none";
  elements.overbudgetAlert.style.display = "none";

  if (percentage < 75) {
    elements.budgetSafetyCard.classList.add("safe");
    elements.budgetStatusPill.innerText = "Aman (< 75%)";
  } else if (percentage < 90) {
    elements.budgetSafetyCard.classList.add("warning");
    elements.budgetStatusPill.innerText = "Waspada (75%-89%)";
    surfaceBudgetAdvisor(remaining, "Waspada: Anggaran terpakai di atas 75%. Pertimbangkan kebutuhan esensial saja.");
  } else if (percentage < 100) {
    elements.budgetSafetyCard.classList.add("warning");
    elements.budgetStatusPill.innerText = "⚠️ KRITIS (90%-99%)";
    surfaceBudgetAdvisor(remaining, "Kritis! Pagu tinggal sedikit. Hentikan menambah barang non-primer.");
  } else {
    elements.budgetSafetyCard.classList.add("danger");
    elements.budgetStatusPill.innerText = "🚨 OVERBUDGET";
    elements.overbudgetAlert.style.display = "flex";
    surfaceBudgetAdvisor(remaining, "Bahaya overbudget! Segera keluarkan barang sekunder dari troli untuk kembali aman.");
    playOverbudgetAlarm();
  }

  // Summary Count
  const totalCount = state.items.length;
  const checkedCount = state.items.filter(i => i.isChecked).length;
  elements.countInCart.innerText = checkedCount;
  elements.countTotal.innerText = totalCount;
  elements.itemSummaryCount.innerHTML = `<span>${checkedCount}</span> / <span>${totalCount}</span> masuk troli (<b>${formatRupiah(checkedTotal)}</b>)`;

  // Update Breakdown Tab Anggaran & Radar
  renderCategoryBreakdown();
  renderStoreComparisonRadar();
  updatePersistenceStatusInfo();
}

/**
 * Smart Budget Safety Advisor (SRS F-05):
 * Menganalisis barang troli yang tergolong sekunder/non-primer (Snack, Minuman, Lain-lain)
 * dan memberikan saran 1-klik untuk mengeluarkan barang tersebut agar dompet kembali aman.
 */
function surfaceBudgetAdvisor(remainingAmount, contextMessage) {
  // Cari item non-primer (Snack & Minuman, Lain-lain, atau barang dengan harga termahal non-pokok)
  const secondaryItems = state.items.filter(i => i.category === "Snack & Minuman" || i.category === "Lain-lain");
  const targetItem = secondaryItems.length > 0 ? secondaryItems[0] : state.items[state.items.length - 1];

  if (!targetItem) return;

  const itemCost = (Number(targetItem.price) || 0) * (Number(targetItem.qty) || 1);
  elements.budgetAdvisorBox.style.display = "flex";
  elements.advisorTitle.innerText = "💡 Saran Penyelamat Dompet Rantau:";
  elements.advisorText.innerHTML = `${contextMessage}<br>Keluarkan <b>"${escapeHtml(targetItem.name)}"</b> (${formatRupiah(itemCost)}) agar anggaran kembali aman.`;

  elements.advisorActionArea.innerHTML = `
    <button class="advisor-btn" data-advisor-drop="${targetItem.id}">
      ✕ Keluarkan "${escapeHtml(targetItem.name)}" Sekarang
    </button>
  `;

  const dropBtn = elements.advisorActionArea.querySelector("[data-advisor-drop]");
  if (dropBtn) {
    dropBtn.onclick = () => {
      state.items = state.items.filter(i => i.id !== targetItem.id);
      showToast(`"${targetItem.name}" dikeluarkan dari troli untuk menyelamatkan anggaran`, "warning");
      commitStateChange();
    };
  }
}

// ============================================================================
// INDIKATOR KOMPARASI FLUKTUASI HARGA REALTIME (SRS F-04)
// ============================================================================
function getPriceFluctuationAnalysis(itemName, currentUnitPrice, currentStore) {
  if (!itemName) return null;
  const lower = itemName.toLowerCase();

  // Match keyword terhadap basis data indeks pasar
  let matchedKey = null;
  for (const key of Object.keys(MARKET_PRICE_DATABASE)) {
    if (lower.includes(key)) {
      matchedKey = key;
      break;
    }
  }

  if (!matchedKey) return null;

  const ref = MARKET_PRICE_DATABASE[matchedKey];
  const avg = ref.avg;
  const currentStoreRef = ref[currentStore] || avg;

  const diffFromAvg = currentUnitPrice - avg;
  const pctFromAvg = Math.round((diffFromAvg / avg) * 100);

  // Cari toko pembanding termurah dan termahal
  let cheapestStore = "Lotte Mart Grocery - Puri Indah";
  let minPrice = Infinity;
  let mostExpensiveStore = "Grand Lucky - Radio Dalam";
  let maxPrice = -Infinity;

  Object.entries(ref).forEach(([store, price]) => {
    if (store !== "baseName" && store !== "unit" && store !== "avg") {
      if (price < minPrice) {
        minPrice = price;
        cheapestStore = store;
      }
      if (price > maxPrice) {
        maxPrice = price;
        mostExpensiveStore = store;
      }
    }
  });

  if (pctFromAvg <= -5) {
    return {
      type: "cheap",
      badge: "▼ Hemat!",
      text: `▼ ${Math.abs(pctFromAvg)}% lebih hemat dari rata-rata (Termurah: ${cheapestStore.split(" - ")[0]})`
    };
  } else if (pctFromAvg >= 5) {
    return {
      type: "expensive",
      badge: "▲ Fluktuasi Naik",
      text: `▲ +${pctFromAvg}% lebih mahal dari pasaran (Di ${cheapestStore.split(" - ")[0]}: ${formatRupiah(minPrice)})`
    };
  } else {
    return {
      type: "neutral",
      badge: "≈ Normal",
      text: `≈ Harga wajar pasar pasaran anak rantau`
    };
  }
}

// ============================================================================
// RADAR KOMPARASI HARGA ANTAR SUPERMARKET (SRS F-04 - TAB 2)
// ============================================================================
function renderStoreComparisonRadar() {
  const container = elements.storeComparisonTable;
  if (!container) return;
  container.innerHTML = "";

  const stores = [
    "Lotte Mart Grocery - Puri Indah",
    "Super Indo Intercon",
    "Indomaret Fresh - Meruya",
    "Hypermart - Puri Indah",
    "Transmart - Central Park",
    "Grand Lucky - Radio Dalam"
  ];

  if (state.items.length === 0) {
    container.innerHTML = `
      <div style="font-size:12px; color:var(--text-muted); text-align:center; padding:12px;">
        Troli masih kosong. Tambahkan barang untuk melihat radar perbandingan harga antar supermarket secara realtime.
      </div>
    `;
    elements.bestDealAlert.style.display = "none";
    return;
  }

  // Hitung total simulasi keranjang jika dibeli di masing-masing supermarket
  const storeTotals = stores.map(store => {
    let simulatedTotal = 0;
    state.items.forEach(item => {
      const lower = item.name.toLowerCase();
      let matchedKey = null;
      for (const key of Object.keys(MARKET_PRICE_DATABASE)) {
        if (lower.includes(key)) {
          matchedKey = key;
          break;
        }
      }

      const qty = Number(item.qty) || 1;
      if (matchedKey && MARKET_PRICE_DATABASE[matchedKey][store]) {
        simulatedTotal += MARKET_PRICE_DATABASE[matchedKey][store] * qty;
      } else {
        // Fallback: gunakan harga item saat ini dengan variasi standar supermarket
        const variance = store.includes("Lotte") ? 0.96 : store.includes("Super Indo") ? 0.98 : store.includes("Indomaret") ? 1.05 : 1.0;
        simulatedTotal += Math.round((Number(item.price) || 0) * variance) * qty;
      }
    });

    return {
      store,
      total: simulatedTotal,
      isCurrent: store === state.storeLocation
    };
  });

  storeTotals.sort((a, b) => a.total - b.total);
  const bestStore = storeTotals[0];
  const currentStoreData = storeTotals.find(s => s.store === state.storeLocation) || storeTotals[0];
  const maxSavings = Math.max(0, currentStoreData.total - bestStore.total);

  storeTotals.forEach(item => {
    const isBest = item.store === bestStore.store;
    const row = document.createElement("div");
    row.className = `store-cmp-row ${isBest ? "best" : ""}`;
    row.innerHTML = `
      <div class="store-cmp-name">
        <span>🏪 ${escapeHtml(item.store.split(" - ")[0])}</span>
        ${isBest ? `<span class="store-cmp-badge best">Termurah!</span>` : ""}
        ${item.isCurrent ? `<span class="store-cmp-badge active">Toko Anda</span>` : ""}
      </div>
      <div class="store-cmp-price">
        <span>${formatRupiah(item.total)}</span>
      </div>
    `;
    container.appendChild(row);
  });

  if (maxSavings > 0 && currentStoreData.store !== bestStore.store) {
    elements.bestDealAlert.style.display = "block";
    elements.bestDealAlert.innerHTML = `
      💡 <b>Tips Penghematan:</b> Belanja keranjang ini di <b>${bestStore.store.split(" - ")[0]}</b> lebih hemat <b>${formatRupiah(maxSavings)}</b> dibanding di ${state.storeLocation.split(" - ")[0]}!
    `;
  } else {
    elements.bestDealAlert.style.display = "block";
    elements.bestDealAlert.innerHTML = `
      🌟 <b>Pilihan Mantap!</b> Anda sedang belanja di <b>${bestStore.store.split(" - ")[0]}</b> yang merupakan supermarket paling hemat untuk daftar belanjaan ini!
    `;
  }
}

// ============================================================================
// RENDER ITEMS LIST (MOBILE CARD ITEM DENGAN SRS F-02, F-03 & F-04)
// ============================================================================
function renderGroceryItems() {
  const container = elements.groceryItemList;
  container.innerHTML = "";

  const filteredItems = state.activeCategory === "ALL" 
    ? state.items 
    : state.items.filter(i => i.category === state.activeCategory);

  if (filteredItems.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
        </div>
        <div class="empty-title">Troli Masih Kosong</div>
        <p class="empty-desc">Tekan tombol "+ Tambah Barang" untuk memasukkan belanjaan ke troli.</p>
      </div>
    `;
    return;
  }

  filteredItems.forEach((item) => {
    const card = document.createElement("div");
    card.className = `grocery-item-card ${item.isChecked ? "checked" : ""}`;
    card.dataset.id = item.id;

    const netPrice = Number(item.price) || 0;
    const basePrice = Number(item.basePrice) || netPrice;
    const qty = Number(item.qty) || 1;
    const subtotal = netPrice * qty;
    const hasDiscount = (item.disc1 > 0 || item.disc2 > 0 || item.discNominal > 0) && basePrice > netPrice;
    const unitSavings = Math.max(0, basePrice - netPrice);

    // Analisis fluktuasi harga realtime (SRS F-04)
    const fluct = getPriceFluctuationAnalysis(item.name, netPrice, state.storeLocation);

    card.innerHTML = `
      <!-- Checkbox Bulat Besar (Ramah Jempol >= 44px) -->
      <button class="item-check-btn" title="Tandai sudah di troli" data-action="toggle-check">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
      </button>

      <!-- Informasi Utama Barang -->
      <div class="item-content" data-action="edit-item">
        <div class="item-badge-row">
          <span class="item-cat-tag">${item.category || "Lain-lain"}</span>
          
          <!-- Badge Diskon Bertingkat Kompound (SRS F-03) -->
          ${hasDiscount ? `
            <span class="item-discount-tag">
              🏷️ Promo ${item.disc1 > 0 ? item.disc1 + '%' : ''}${item.disc2 > 0 ? ' + ' + item.disc2 + '%' : ''}${item.discNominal > 0 ? ' + Rp' + item.discNominal : ''}
            </span>
          ` : ""}

          ${item.notes ? `<span class="item-notes">🏷️ ${escapeHtml(item.notes)}</span>` : ""}
        </div>

        <div class="item-name">${escapeHtml(item.name)}</div>

        <!-- Harga & Penghematan -->
        <div class="item-price-row">
          <span class="item-subtotal">${formatRupiah(subtotal)}</span>
          <span class="item-unit-calc">
            ${hasDiscount ? `<span class="item-original-price">${formatRupiah(basePrice)}</span>` : ""}
            (${formatRupiah(netPrice)}/${item.unit || "pcs"})
          </span>
          ${hasDiscount ? `<span class="item-savings-pill">Hemat ${formatRupiah(unitSavings * qty)}</span>` : ""}
        </div>

        <!-- Indikator Fluktuasi Harga Realtime (SRS F-04) -->
        ${fluct ? `
          <div class="fluctuation-tag ${fluct.type}">
            <span>${fluct.badge}:</span> <span>${escapeHtml(fluct.text)}</span>
          </div>
        ` : ""}
      </div>

      <!-- Tombol Gandakan Kuantitas Instan 0 Delay (SRS F-02) -->
      <button class="btn-duplicate-qty" data-action="quick-duplicate" title="Gandakan Kuantitas (+1) Tanpa Delay">
        <span>+1</span>
        <span style="font-size:10px;">⚡</span>
      </button>

      <!-- Stepper Kuantitas [-] Qty [+] (Ramah Jempol) -->
      <div class="stepper-group">
        <button class="stepper-btn" data-action="decrease-qty" title="Kurangi">−</button>
        <span class="stepper-val">${item.qty}</span>
        <button class="stepper-btn" data-action="increase-qty" title="Tambah">+</button>
      </div>

      <!-- Tombol Hapus -->
      <button class="item-delete-btn" data-action="delete-item" title="Hapus dari troli">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
      </button>
    `;

    // Event delegation handling per card
    card.addEventListener("click", (e) => {
      const targetBtn = e.target.closest("[data-action]");
      if (!targetBtn) return;
      const action = targetBtn.dataset.action;

      if (action === "toggle-check") {
        item.isChecked = !item.isChecked;
        playCartSound();
        commitStateChange();
      } else if (action === "quick-duplicate") {
        // PENGGANDAAN KUANTITAS INSTAN 0 DELAY (SRS F-02)
        item.qty = (Number(item.qty) || 1) + 1;
        playDuplicateSound();
        showToast(`⚡ Kuantitas "${item.name}" digandakan menjadi ${item.qty} tanpa delay!`, "success");
        commitStateChange();
      } else if (action === "increase-qty") {
        item.qty = (Number(item.qty) || 1) + 1;
        playCartSound();
        commitStateChange();
      } else if (action === "decrease-qty") {
        if (item.qty > 1) {
          item.qty -= 1;
          playCartSound();
          commitStateChange();
        } else {
          confirmDeleteItem(item.id);
        }
      } else if (action === "delete-item") {
        confirmDeleteItem(item.id);
      } else if (action === "edit-item") {
        openEditItemModal(item);
      }
    });

    container.appendChild(card);
  });
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function confirmDeleteItem(itemId) {
  const item = state.items.find(i => i.id === itemId);
  if (!item) return;
  if (confirm(`Hapus "${item.name}" dari troli belanja?`)) {
    state.items = state.items.filter(i => i.id !== itemId);
    showToast(`"${item.name}" dihapus dari troli`, "info");
    commitStateChange();
  }
}

// ============================================================================
// COMMIT STATE CHANGE (SINKRONISASI FIRESTORE & LOCALSTORAGE - SRS F-06A & F-06B)
// ============================================================================
function commitStateChange() {
  calculateBudgetSafety();
  renderGroceryItems();

  const payload = {
    sessionId: state.sessionId,
    storeLocation: state.storeLocation,
    shoppingDate: state.shoppingDate,
    walletLimit: state.walletLimit,
    totalSpent: state.totalSpent,
    totalSavings: state.totalSavings,
    items: state.items
  };

  saveSessionData(state.sessionId, payload);
}

// ============================================================================
// RENDER BREAKDOWN KATEGORI (TAB ANGGARAN)
// ============================================================================
function renderCategoryBreakdown() {
  const container = elements.categoryBreakdownList;
  if (!container) return;
  container.innerHTML = "";

  const catMap = {};
  state.items.forEach(item => {
    const cat = item.category || "Lain-lain";
    const sub = (Number(item.price) || 0) * (Number(item.qty) || 1);
    catMap[cat] = (catMap[cat] || 0) + sub;
  });

  const total = state.totalSpent || 1;

  Object.keys(catMap).forEach(cat => {
    const val = catMap[cat];
    const pct = Math.round((val / total) * 100);

    const row = document.createElement("div");
    row.className = "category-breakdown-row";
    row.innerHTML = `
      <div class="cat-breakdown-labels">
        <span style="font-weight:600; color:#fff;">${cat}</span>
        <span style="color:var(--text-muted);">${formatRupiah(val)} (${pct}%)</span>
      </div>
      <div class="cat-breakdown-bar">
        <div class="cat-breakdown-fill" style="width: ${pct}%;"></div>
      </div>
    `;
    container.appendChild(row);
  });
}

// ============================================================================
// RENDER RIWAYAT TOKO (TAB RIWAYAT)
// ============================================================================
function loadHistoryReceipts() {
  const container = elements.historyListContainer;
  if (!container) return;
  container.innerHTML = "";

  let historyData = [];
  try {
    const raw = localStorage.getItem("grocery_history_receipts");
    if (raw) historyData = JSON.parse(raw);
  } catch (e) {}

  if (historyData.length === 0) {
    historyData = [
      {
        id: "hist_1",
        store: "Lotte Mart Grocery - Puri Indah",
        date: "2026-10-14",
        total: 485000,
        itemCount: 12,
        savings: "Hemat Rp 35.000 dengan promo karton beras"
      },
      {
        id: "hist_2",
        store: "Super Indo Intercon",
        date: "2026-09-28",
        total: 390000,
        itemCount: 9,
        savings: "Promo kompound daging ayam & telur segar"
      }
    ];
    localStorage.setItem("grocery_history_receipts", JSON.stringify(historyData));
  }

  historyData.forEach(h => {
    const el = document.createElement("div");
    el.className = "history-card";
    el.innerHTML = `
      <div class="history-header">
        <span class="history-store">🏪 ${escapeHtml(h.store)}</span>
        <span class="history-date">${h.date}</span>
      </div>
      <div class="history-stats">
        <div class="history-stat-box">
          <div class="history-stat-label">Total Belanja</div>
          <div class="history-stat-val">${formatRupiah(h.total)}</div>
        </div>
        <div class="history-stat-box">
          <div class="history-stat-label">Jumlah Barang</div>
          <div class="history-stat-val" style="color:#fff;">${h.itemCount} items</div>
        </div>
      </div>
      <p style="font-size:11px; color:#34d399;">💡 ${escapeHtml(h.savings || "Belanja bulanan terkendali")}</p>
    `;
    container.appendChild(el);
  });
}

function saveCurrentSessionToHistory() {
  if (state.items.length === 0) {
    alert("Troli masih kosong. Tambahkan barang sebelum menyelesaikan sesi.");
    return;
  }

  const receipt = {
    id: `receipt_${Date.now()}`,
    store: state.storeLocation,
    date: state.shoppingDate,
    total: state.totalSpent,
    itemCount: state.items.length,
    savings: `Selesai belanja di ${state.storeLocation} (Hemat: ${formatRupiah(state.totalSavings)})`
  };

  let historyData = [];
  try {
    const raw = localStorage.getItem("grocery_history_receipts");
    if (raw) historyData = JSON.parse(raw);
  } catch (e) {}

  historyData.unshift(receipt);
  localStorage.setItem("grocery_history_receipts", JSON.stringify(historyData));
  showToast(`✅ Sesi belanja berhasil disimpan ke Riwayat!`, "success");
  loadHistoryReceipts();
}

// ============================================================================
// PANEL UJI PERSISTENSI DATA LOKAL (SRS F-06A)
// ============================================================================
function updatePersistenceStatusInfo() {
  if (!elements.persistenceInfoText) return;
  const count = state.items.length;
  const raw = localStorage.getItem(`grocery_session_${state.sessionId}`) || "";
  const kb = (raw.length / 1024).toFixed(1);
  elements.persistenceInfoText.innerText = `${count} items (${kb} KB) tersimpan aman`;
}

function exportSessionToJson() {
  const exportData = {
    sessionId: state.sessionId,
    storeLocation: state.storeLocation,
    shoppingDate: state.shoppingDate,
    walletLimit: state.walletLimit,
    totalSpent: state.totalSpent,
    totalSavings: state.totalSavings,
    items: state.items,
    exportedAt: new Date().toISOString()
  };

  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
  const downloadAnchor = document.createElement("a");
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", `grocery_backup_${state.sessionId}_${Date.now()}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();

  showToast("💾 Berkas backup JSON berhasil diekspor!", "success");
}

function importSessionFromJson(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const parsed = JSON.parse(e.target.result);
      if (Array.isArray(parsed.items)) {
        state.items = parsed.items;
        if (parsed.storeLocation) state.storeLocation = parsed.storeLocation;
        if (parsed.shoppingDate) state.shoppingDate = parsed.shoppingDate;
        if (parsed.walletLimit) state.walletLimit = Number(parsed.walletLimit);

        elements.storeSelector.value = state.storeLocation;
        elements.shoppingDateInput.value = state.shoppingDate;
        elements.inputWalletLimitSettings.value = state.walletLimit;

        commitStateChange();
        showToast("📂 Berkas JSON berhasil dipulihkan ke troli!", "success");
      } else {
        alert("Format berkas JSON tidak sesuai struktur belanja.");
      }
    } catch (err) {
      alert("Gagal membaca file JSON: " + err.message);
    }
  };
  reader.readAsText(file);
}

function resetToDefaultDemo() {
  if (confirm("Reset data ke demo awal pengujian? Seluruh perubahan saat ini akan diganti dengan skenario standar.")) {
    const defaultData = createDefaultSessionData(state.sessionId);
    state.storeLocation = defaultData.storeLocation;
    state.shoppingDate = defaultData.shoppingDate;
    state.walletLimit = defaultData.walletLimit;
    state.items = defaultData.items;

    elements.storeSelector.value = state.storeLocation;
    elements.shoppingDateInput.value = state.shoppingDate;
    elements.inputWalletLimitSettings.value = state.walletLimit;

    commitStateChange();
    showToast("🧹 Data belanja berhasil direset ke demo awal", "info");
  }
}

// ============================================================================
// MODAL INTERACTIONS & DISKON BERTINGKAT LIVE SIMULATOR (SRS F-03)
// ============================================================================
function updateLiveCompoundDiscountCalculation() {
  const basePrice = Number(elements.inputItemPrice.value) || 0;
  const d1 = Number(elements.inputDisc1.value) || 0;
  const d2 = Number(elements.inputDisc2.value) || 0;
  const nom = Number(elements.inputDiscNominal.value) || 0;

  const res = calculateCompoundPrice(basePrice, d1, d2, nom);

  elements.calcBasePriceDisplay.innerText = formatRupiah(res.basePrice);
  elements.calcDiscountSavingsDisplay.innerText = `-Rp ${formatRupiah(res.totalUnitSavings)} (${res.effectivePercent}%)`;
  elements.calcNetPriceDisplay.innerText = formatRupiah(res.netUnitPrice);
}

function openAddItemModal() {
  elements.modalTitle.innerText = "Tambah Barang Troli";
  elements.editItemId.value = "";
  elements.itemForm.reset();
  elements.inputItemQty.value = "1";
  elements.inputDisc1.value = "0";
  elements.inputDisc2.value = "0";
  elements.inputDiscNominal.value = "0";

  document.querySelectorAll(".preset-disc-btn").forEach(b => b.classList.remove("active"));
  const defBtn = document.querySelector('.preset-disc-btn[data-d1="0"]');
  if (defBtn) defBtn.classList.add("active");

  updateLiveCompoundDiscountCalculation();
  elements.itemModalOverlay.classList.add("open");
  setTimeout(() => elements.inputItemName.focus(), 200);
}

function openEditItemModal(item) {
  elements.modalTitle.innerText = "Edit Barang Troli";
  elements.editItemId.value = item.id;
  elements.inputItemName.value = item.name;
  elements.inputItemCategory.value = item.category || "Kebutuhan Pokok";
  elements.inputItemUnit.value = item.unit || "pcs";
  elements.inputItemPrice.value = item.basePrice || item.price;
  elements.inputItemQty.value = item.qty;
  elements.inputItemNotes.value = item.notes || "";

  elements.inputDisc1.value = item.disc1 || 0;
  elements.inputDisc2.value = item.disc2 || 0;
  elements.inputDiscNominal.value = item.discNominal || 0;

  updateLiveCompoundDiscountCalculation();
  elements.itemModalOverlay.classList.add("open");
}

function closeItemModal() {
  elements.itemModalOverlay.classList.remove("open");
}

// Preset Diskon Cepat
document.querySelectorAll(".preset-disc-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".preset-disc-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");

    elements.inputDisc1.value = btn.dataset.d1 || 0;
    elements.inputDisc2.value = btn.dataset.d2 || 0;
    elements.inputDiscNominal.value = btn.dataset.nom || 0;

    updateLiveCompoundDiscountCalculation();
  });
});

[elements.inputItemPrice, elements.inputDisc1, elements.inputDisc2, elements.inputDiscNominal].forEach(el => {
  if (el) {
    el.addEventListener("input", updateLiveCompoundDiscountCalculation);
  }
});

// Saran Cepat Nama Barang Ramah Jempol
if (elements.quickItemSuggestions) {
  elements.quickItemSuggestions.addEventListener("click", (e) => {
    const chip = e.target.closest(".suggestion-chip");
    if (!chip) return;
    elements.inputItemName.value = chip.dataset.name;
    elements.inputItemCategory.value = chip.dataset.cat;
    elements.inputItemUnit.value = chip.dataset.unit;
    elements.inputItemPrice.value = chip.dataset.price;
    updateLiveCompoundDiscountCalculation();
    triggerHaptic([20]);
  });
}

// ============================================================================
// SUBMIT FORM TAMBAH / EDIT BARANG (DENGAN PENGGANDAAN OTOMATIS TANPA DELAY - SRS F-02)
// ============================================================================
elements.itemForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const editId = elements.editItemId.value;
  const name = elements.inputItemName.value.trim();
  const category = elements.inputItemCategory.value;
  const unit = elements.inputItemUnit.value;
  const basePrice = Number(elements.inputItemPrice.value) || 0;
  const qty = Number(elements.inputItemQty.value) || 1;
  const notes = elements.inputItemNotes.value.trim();

  const disc1 = Number(elements.inputDisc1.value) || 0;
  const disc2 = Number(elements.inputDisc2.value) || 0;
  const discNominal = Number(elements.inputDiscNominal.value) || 0;

  if (!name || basePrice <= 0) {
    alert("Harap isi nama barang dan harga satuan yang valid.");
    return;
  }

  // Hitung diskon bertingkat kompound (SRS F-03)
  const calc = calculateCompoundPrice(basePrice, disc1, disc2, discNominal);
  const finalUnitPrice = calc.netUnitPrice;

  if (editId) {
    // Mode Edit
    const item = state.items.find(i => i.id === editId);
    if (item) {
      item.name = name;
      item.category = category;
      item.unit = unit;
      item.basePrice = basePrice;
      item.price = finalUnitPrice;
      item.disc1 = disc1;
      item.disc2 = disc2;
      item.discNominal = discNominal;
      item.qty = qty;
      item.notes = notes;
      showToast(`Barang "${name}" berhasil diperbarui`, "success");
    }
  } else {
    // ========================================================================
    // PENGGANDAAN KUANTITAS OTOMATIS TANPA DELAY (SRS F-02)
    // Cek apakah barang dengan nama yang sama persis (case-insensitive) sudah ada
    // ========================================================================
    const existingIndex = state.items.findIndex(
      i => i.name.trim().toLowerCase() === name.toLowerCase() && i.unit === unit
    );

    if (existingIndex !== -1) {
      // DITEMUKAN BARANG SAMA: Gandakan kuantitas seketika tanpa jeda!
      const existingItem = state.items[existingIndex];
      const oldQty = existingItem.qty;
      existingItem.qty = (Number(existingItem.qty) || 1) + qty;
      existingItem.basePrice = basePrice;
      existingItem.price = finalUnitPrice;
      existingItem.disc1 = disc1;
      existingItem.disc2 = disc2;
      existingItem.discNominal = discNominal;
      if (notes) existingItem.notes = notes;

      playDuplicateSound();
      showToast(`⚡ Kuantitas "${name}" otomatis digandakan: ${oldQty} ➔ ${existingItem.qty} (+${qty}) tanpa delay!`, "success");
    } else {
      // Tambah item baru
      const newItem = {
        id: `item_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
        name,
        category,
        unit,
        basePrice,
        price: finalUnitPrice,
        disc1,
        disc2,
        discNominal,
        qty,
        notes,
        isChecked: true // Otomatis masuk troli
      };
      state.items.push(newItem);
      playCartSound();
      showToast(`"${name}" ditambahkan ke troli`, "success");
    }
  }

  closeItemModal();
  commitStateChange();
});

// Shortcut Tambah Harga Cepat (+5k, +10k, dll)
document.querySelectorAll("[data-add-price]").forEach(btn => {
  btn.addEventListener("click", () => {
    const addVal = Number(btn.dataset.addPrice) || 0;
    const current = Number(elements.inputItemPrice.value) || 0;
    elements.inputItemPrice.value = current + addVal;
    updateLiveCompoundDiscountCalculation();
    triggerHaptic([15]);
  });
});

// ============================================================================
// HEADER SELECTOR EVENTS & TOKO KUSTOM (SRS F-01)
// ============================================================================
function populateCustomStoresInSelector() {
  const selector = elements.storeSelector;
  // Hapus opsi kustom lama sebelum menambah
  const existingCustoms = selector.querySelectorAll(".custom-opt");
  existingCustoms.forEach(o => o.remove());

  const addCustomOpt = selector.querySelector('option[value="__add_custom_store__"]');

  state.customStores.forEach(storeName => {
    const opt = document.createElement("option");
    opt.value = storeName;
    opt.className = "custom-opt";
    opt.innerText = `🏪 ${storeName}`;
    selector.insertBefore(opt, addCustomOpt);
  });
}

elements.storeSelector.addEventListener("change", (e) => {
  if (e.target.value === "__add_custom_store__") {
    // Buka modal tambah toko kustom
    elements.inputNewStoreName.value = "";
    elements.customStoreModalOverlay.classList.add("open");
    setTimeout(() => elements.inputNewStoreName.focus(), 200);
    // Kembalikan sementara ke toko aktif
    elements.storeSelector.value = state.storeLocation;
  } else {
    state.storeLocation = e.target.value;
    commitStateChange();
    showToast(`Lokasi toko diubah ke ${state.storeLocation.split(" - ")[0]}`, "info");
  }
});

elements.closeCustomStoreModalBtn.addEventListener("click", () => {
  elements.customStoreModalOverlay.classList.remove("open");
});

elements.btnSaveCustomStore.addEventListener("click", () => {
  const storeName = elements.inputNewStoreName.value.trim();
  if (!storeName) {
    alert("Masukkan nama toko / minimarket.");
    return;
  }

  if (!state.customStores.includes(storeName)) {
    state.customStores.push(storeName);
    localStorage.setItem("custom_stores_list", JSON.stringify(state.customStores));
    populateCustomStoresInSelector();
  }

  state.storeLocation = storeName;
  elements.storeSelector.value = storeName;
  elements.customStoreModalOverlay.classList.remove("open");
  commitStateChange();
  showToast(`Toko baru "${storeName}" disimpan & dipilih`, "success");
});

elements.shoppingDateInput.addEventListener("change", (e) => {
  state.shoppingDate = e.target.value;
  commitStateChange();
  showToast(`Tanggal transaksi diatur ke ${state.shoppingDate}`, "info");
});

// Category Chips Filtering
elements.catChipsContainer.addEventListener("click", (e) => {
  const chip = e.target.closest(".cat-chip");
  if (!chip) return;
  document.querySelectorAll(".cat-chip").forEach(c => c.classList.remove("active"));
  chip.classList.add("active");
  state.activeCategory = chip.dataset.cat;
  renderGroceryItems();
  triggerHaptic([15]);
});

// Tab Navigation
elements.bottomNavBar.addEventListener("click", (e) => {
  const tabBtn = e.target.closest(".nav-tab-btn");
  if (!tabBtn) return;
  const targetPaneId = tabBtn.dataset.tab;

  document.querySelectorAll(".nav-tab-btn").forEach(b => b.classList.remove("active"));
  tabBtn.classList.add("active");

  elements.paneBelanja.style.display = targetPaneId === "paneBelanja" ? "block" : "none";
  elements.paneRiwayat.style.display = targetPaneId === "paneRiwayat" ? "block" : "none";
  elements.paneAnggaran.style.display = targetPaneId === "paneAnggaran" ? "block" : "none";

  triggerHaptic([20]);

  if (targetPaneId === "paneRiwayat") {
    loadHistoryReceipts();
    renderStoreComparisonRadar();
  }
  if (targetPaneId === "paneAnggaran") {
    renderCategoryBreakdown();
    updatePersistenceStatusInfo();
  }
});

// Budget Settings Handlers (SRS F-05)
elements.btnSaveLimitSettings.addEventListener("click", () => {
  const newLimit = Number(elements.inputWalletLimitSettings.value);
  if (newLimit > 0) {
    state.walletLimit = newLimit;
    commitStateChange();
    showToast(`Pagu anggaran berhasil diatur ke ${formatRupiah(newLimit)}`, "success");
  }
});

document.querySelectorAll("[data-set-limit]").forEach(btn => {
  btn.addEventListener("click", () => {
    const val = Number(btn.dataset.setLimit);
    elements.inputWalletLimitSettings.value = val;
    state.walletLimit = val;
    commitStateChange();
    showToast(`Pagu anggaran: ${formatRupiah(val)}`, "info");
    triggerHaptic([20]);
  });
});

// Open modal triggers
elements.openAddItemModalBtn.addEventListener("click", openAddItemModal);
elements.closeItemModalBtn.addEventListener("click", closeItemModal);
elements.openBudgetLimitBtn.addEventListener("click", () => {
  document.querySelector('[data-tab="paneAnggaran"]').click();
});
elements.saveSessionToHistoryBtn.addEventListener("click", saveCurrentSessionToHistory);

// Panel Uji Persistensi Triggers (SRS F-06A)
elements.btnTestReloadSimulation.addEventListener("click", () => {
  showToast("Menguji persistensi data lokal (F5)...", "info");
  setTimeout(() => {
    window.location.reload();
  }, 400);
});

elements.btnExportJsonBackup.addEventListener("click", exportSessionToJson);
elements.btnImportJsonTrigger.addEventListener("click", () => {
  elements.inputJsonFile.click();
});
elements.inputJsonFile.addEventListener("change", (e) => {
  if (e.target.files && e.target.files[0]) {
    importSessionFromJson(e.target.files[0]);
  }
});
elements.btnResetToDefaultDemo.addEventListener("click", resetToDefaultDemo);

// ============================================================================
// REALTIME SESSION & MULTI-DEVICE LAUNCHER (SRS F-06B)
// ============================================================================
elements.syncBadgeBtn.addEventListener("click", () => {
  elements.inputSessionId.value = state.sessionId;
  elements.inputCustomFirebaseJson.value = JSON.stringify(activeFirebaseConfig, null, 2);
  elements.syncModalOverlay.classList.add("open");
});

elements.closeSyncModalBtn.addEventListener("click", () => {
  elements.syncModalOverlay.classList.remove("open");
});

// Launch Companion Window (Simulasi HP / Tab Pendamping)
elements.btnLaunchCompanionWindow.addEventListener("click", () => {
  const companionUrl = `${window.location.origin}${window.location.pathname}?session=${encodeURIComponent(state.sessionId)}`;
  window.open(companionUrl, "_blank", "width=420,height=820,left=150,top=100");
  showToast("📱 Jendela simulasi HP kedua dibuka berdampingan!", "success");
});

elements.btnApplySessionSettings.addEventListener("click", () => {
  const newSessionId = elements.inputSessionId.value.trim();
  if (newSessionId) {
    state.sessionId = newSessionId;
    localStorage.setItem("active_grocery_session_id", newSessionId);
  }

  const rawJson = elements.inputCustomFirebaseJson.value.trim();
  if (rawJson) {
    try {
      const parsed = JSON.parse(rawJson);
      saveCustomFirebaseConfig(parsed);
    } catch (e) {
      alert("Format JSON Firebase tidak valid. Pengaturan lokal tetap disimpan.");
    }
  }

  elements.syncModalOverlay.classList.remove("open");
  startRealtimeListener();
  showToast(`Sesi "${state.sessionId}" aktif`, "info");
});

// Log Stream Aktivitas Realtime
function logSyncActivity(message, type = "info") {
  const container = elements.syncActivityLog;
  if (!container) return;

  const entry = document.createElement("div");
  entry.className = `log-entry ${type}`;
  const now = new Date().toLocaleTimeString("id-ID", { hour12: false });
  entry.innerText = `[${now}] ${message}`;

  container.prepend(entry);
  while (container.children.length > 25) {
    container.removeChild(container.lastChild);
  }
}

// ============================================================================
// REALTIME SNAPSHOT HANDLER & INITIALIZATION (SRS F-06B)
// ============================================================================
function onDataReceivedFromStream(data, source) {
  if (!data) return;

  logSyncActivity(`Menerima payload realtime (${data.items?.length || 0} barang) via ${source}`, "incoming");

  // Sinkronkan seluruh state aplikasi seketika tanpa refresh
  if (data.storeLocation) {
    state.storeLocation = data.storeLocation;
    elements.storeSelector.value = data.storeLocation;
  }
  if (data.shoppingDate) {
    state.shoppingDate = data.shoppingDate;
    elements.shoppingDateInput.value = data.shoppingDate;
  }
  if (data.walletLimit) {
    state.walletLimit = Number(data.walletLimit);
    elements.inputWalletLimitSettings.value = state.walletLimit;
  }
  if (Array.isArray(data.items)) {
    state.items = data.items;
  }

  calculateBudgetSafety();
  renderGroceryItems();
}

function onConnectionStatusChanged(statusInfo) {
  const badge = elements.syncBadgeBtn;
  const label = elements.syncStatusLabel;
  const details = elements.syncDetailsBox;

  badge.className = `sync-badge ${statusInfo.status}`;
  
  if (statusInfo.status === "online") {
    label.innerText = "Realtime Cloud Aktif";
    if (details) details.innerHTML = `<span style="color:#34d399;">🟢 Cloud Firestore Realtime Stream Aktif</span><br>Sesi: <b>${state.sessionId}</b>`;
  } else if (statusInfo.status === "local_ready") {
    label.innerText = "Offline / Aman";
    if (details) details.innerHTML = `<span style="color:#fbbf24;">🟡 Multi-Tab & LocalStorage Stream Aktif</span><br>Sinkronisasi antar-tab aktif. Sesi: <b>${state.sessionId}</b>`;
  } else {
    label.innerText = "Menghubungkan...";
    if (details) details.innerText = statusInfo.text;
  }
}

function startRealtimeListener() {
  listenToShoppingSession(state.sessionId, onDataReceivedFromStream, onConnectionStatusChanged, logSyncActivity);
}

// ============================================================================
// BOOTSTRAP INITIAL RUN
// ============================================================================
function initApp() {
  // Cek apakah ada query param ?session=... dari jendela pendamping
  const urlParams = new URLSearchParams(window.location.search);
  const sessionParam = urlParams.get("session");
  if (sessionParam) {
    state.sessionId = sessionParam;
    localStorage.setItem("active_grocery_session_id", sessionParam);
  }

  // Populate custom stores
  populateCustomStoresInSelector();

  // Set default values
  elements.shoppingDateInput.value = state.shoppingDate;
  elements.storeSelector.value = state.storeLocation;
  elements.inputWalletLimitSettings.value = state.walletLimit;

  // Mulai listener realtime Firestore onSnapshot dengan Fallback LocalStorage
  startRealtimeListener();

  // Load history list awal & radar
  loadHistoryReceipts();
  renderStoreComparisonRadar();
  updatePersistenceStatusInfo();
}

initApp();
