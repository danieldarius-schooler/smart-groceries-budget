// ============================================================================
// FIREBASE CONFIGURATION & REALTIME MULTI-DEVICE SYNC ENGINE (SRS F-06B)
// "Smart Grocery & Budget Safety Tracker"
// ============================================================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { 
  getFirestore, 
  doc, 
  onSnapshot, 
  setDoc, 
  updateDoc 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

// Konfigurasi Cloud Firestore
// Pengguna dapat mengganti nilai ini via Modal Sinkronisasi di dalam aplikasi.
export const defaultFirebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "proyek-kamu.firebaseapp.com",
  projectId: "proyek-kamu",
  storageBucket: "proyek-kamu.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:..."
};

// Ambil config tersimpan di LocalStorage jika pengguna pernah mengupdate lewat UI
const storedConfig = localStorage.getItem("firebase_custom_config");
export let activeFirebaseConfig = storedConfig ? JSON.parse(storedConfig) : defaultFirebaseConfig;

let app = null;
let db = null;
let unsubscribeSnapshot = null;
let broadcastChannel = null;
let logCallback = null;

// Cek apakah konfigurasi masih default / placeholder
export function isConfigPlaceholder(cfg) {
  return !cfg || !cfg.apiKey || cfg.apiKey.includes("...") || cfg.projectId === "proyek-kamu";
}

// Inisialisasi Firebase App & Firestore
export function initFirebase() {
  if (isConfigPlaceholder(activeFirebaseConfig)) {
    console.info("ℹ️ Firebase config placeholder. Mengaktifkan Realtime Local-Broadcast & Fallback Mode.");
    return false;
  }

  try {
    app = initializeApp(activeFirebaseConfig);
    db = getFirestore(app);
    console.log("✅ Firebase Firestore berhasil diinisialisasi.");
    return true;
  } catch (error) {
    console.warn("⚠️ Gagal inisialisasi Firebase:", error);
    return false;
  }
}

// Inisialisasi awal saat script dimuat
const isFirebaseLive = initFirebase();

// Setup BroadcastChannel untuk sinkronisasi multi-tab/perangkat lokal saat offline/demo
if ('BroadcastChannel' in window) {
  try {
    broadcastChannel = new BroadcastChannel('grocery_realtime_channel');
  } catch (e) {
    console.warn("BroadcastChannel tidak tersedia", e);
  }
}

function emitLog(message, type = "info") {
  if (typeof logCallback === "function") {
    logCallback(message, type);
  }
}

// ============================================================================
// REALTIME LISTENER ENGINE (onSnapshot) DENGAN FALLBACK LOCALSTORAGE (SRS F-06B)
// ============================================================================

/**
 * Mendengarkan perubahan data sesi belanja secara REALTIME.
 * @param {string} sessionId ID sesi belanja (misal: "sesi-lotte-mart-puri")
 * @param {function} onDataReceived Callback saat data berubah (otomatis render UI seketika)
 * @param {function} onStatusChanged Callback indikator status koneksi
 * @param {function} onLog Callback pencatatan stream realtime
 */
export function listenToShoppingSession(sessionId, onDataReceived, onStatusChanged, onLog) {
  if (onLog) logCallback = onLog;

  // 1. Hentikan listener lama jika ada pergantian sesi
  if (unsubscribeSnapshot) {
    unsubscribeSnapshot();
    unsubscribeSnapshot = null;
  }

  // 2. FAST FIRST PAINT: Cek dan load segera dari LocalStorage agar tidak blank saat dibuka / F5 (SRS F-06A)
  const localCache = getBackupFromLocalStorage(sessionId);
  if (localCache) {
    console.log("⚡ [Fast First Paint] Memuat data dari LocalStorage:", localCache);
    emitLog(`⚡ Data lokal sesi "${sessionId}" dimuat instan`, "incoming");
    onDataReceived(localCache, "local_cache");
  }

  // 3. JIKA FIREBASE AKTIF DAN BUKAN PLACEHOLDER: GUNAKAN onSnapshot() (SRS F-06B)
  if (db && !isConfigPlaceholder(activeFirebaseConfig)) {
    try {
      onStatusChanged({ status: "connecting", text: "Menghubungkan ke Cloud Firestore..." });
      const sessionRef = doc(db, "shopping_sessions", sessionId);

      // PENTING: Gunakan onSnapshot (Realtime Stream Listener), JANGAN getDoc() sekali jalan
      unsubscribeSnapshot = onSnapshot(sessionRef, (docSnap) => {
        if (docSnap.exists()) {
          const cloudData = docSnap.data();
          console.log("🔥 [Cloud Firestore onSnapshot] Pembaruan realtime diterima:", cloudData);
          emitLog(`🔥 [Cloud Firestore] Snapshot diterima (${cloudData.items?.length || 0} barang)`, "incoming");
          
          // Simpan snapshot terbaru ke LocalStorage sebagai backup offline seketika (SRS F-06A)
          saveBackupToLocalStorage(sessionId, cloudData);

          // Update UI HP & PC secara instan tanpa reload halaman
          onDataReceived(cloudData, "firestore_realtime");
          onStatusChanged({ status: "online", text: "Cloud Firestore Realtime Sync", device: "cloud" });
        } else {
          console.log("ℹ️ Sesi belum ada di Firestore, menginisialisasi sesi baru...");
          const initial = localCache || createDefaultSessionData(sessionId);
          saveSessionData(sessionId, initial);
          onDataReceived(initial, "new_session");
          onStatusChanged({ status: "online", text: "Cloud Firestore Terhubung (Sesi Baru)" });
        }
      }, (error) => {
        console.error("❌ Firestore onSnapshot Error:", error);
        emitLog(`❌ Firestore stream error: ${error.message}`, "danger");
        onStatusChanged({ status: "offline", text: "Offline / Fallback LocalStorage Aktif" });
      });

      return;
    } catch (err) {
      console.warn("⚠️ Gagal memasang onSnapshot, beralih ke Fallback Mode:", err);
    }
  }

  // 4. FALLBACK REALTIME MODE (OFFLINE / PLACEHOLDER CONFIG / DEMO):
  // Memastikan sinkronisasi multi-device & multi-tab bekerja instan tanpa jeda
  onStatusChanged({ 
    status: "local_ready", 
    text: "Mode Offline / LocalStorage Safe (Multi-Tab Realtime Aktif)" 
  });
  emitLog(`📡 Realtime Multi-Tab Stream siap (Sesi: ${sessionId})`, "info");

  // Listener antar-tab dan antar-jendela browser
  if (broadcastChannel) {
    broadcastChannel.onmessage = (event) => {
      if (event.data && event.data.sessionId === sessionId) {
        console.log("📡 [BroadcastChannel Realtime] Sinkronisasi antar-tab:", event.data.data);
        emitLog(`📡 [Multi-Device/Tab Sync] Diterima update (${event.data.data.items?.length || 0} barang)`, "incoming");
        onDataReceived(event.data.data, "broadcast_realtime");
      }
    };
  }

  // Storage event listener untuk browser fallback
  window.addEventListener('storage', (e) => {
    if (e.key === `grocery_session_${sessionId}` && e.newValue) {
      try {
        const parsed = JSON.parse(e.newValue);
        emitLog(`💾 [Storage Event Sync] Update terdeteksi`, "incoming");
        onDataReceived(parsed, "storage_realtime");
      } catch (err) {}
    }
  });
}

// ============================================================================
// WRITE ENGINE: MENYIMPAN DATA KE FIRESTORE & LOCALSTORAGE
// ============================================================================

/**
 * Menyimpan data perubahan barang/anggaran ke Cloud Firestore dan LocalStorage sekaligus.
 */
export async function saveSessionData(sessionId, data) {
  const payload = {
    ...data,
    sessionId: sessionId,
    lastUpdated: new Date().toISOString()
  };

  // 1. Selalu simpan ke LocalStorage seketika (Jaminan integritas SRS F-06A)
  saveBackupToLocalStorage(sessionId, payload);

  // 2. Broadcast ke tab / jendela lain jika dalam mode multi-tab (SRS F-06B fallback)
  if (broadcastChannel) {
    try {
      broadcastChannel.postMessage({ sessionId, data: payload });
      emitLog(`📤 [Multi-Device Broadcast] Mengirim update (${payload.items?.length || 0} barang)`, "outgoing");
    } catch (e) {}
  }

  // 3. Simpan ke Cloud Firestore jika kredensial aktif
  if (db && !isConfigPlaceholder(activeFirebaseConfig) && navigator.onLine) {
    try {
      const sessionRef = doc(db, "shopping_sessions", sessionId);
      await setDoc(sessionRef, payload, { merge: true });
      emitLog(`☁️ [Cloud Firestore Sync] Tersimpan ke cloud`, "outgoing");
      return { success: true, target: "cloud" };
    } catch (error) {
      console.warn("⚠️ Gagal menyimpan ke Firestore (tersimpan di LocalStorage):", error);
      emitLog(`⚠️ Gagal sync cloud (tersimpan lokal): ${error.message}`, "warning");
      return { success: true, target: "local_fallback", error };
    }
  }

  return { success: true, target: "local" };
}

// ============================================================================
// HELPER STORAGE & DATA DEFAULT (SRS F-06A & F-01 s/d F-05)
// ============================================================================

export function getBackupFromLocalStorage(sessionId) {
  try {
    const raw = localStorage.getItem(`grocery_session_${sessionId}`) || localStorage.getItem("grocery_backup");
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error("Gagal membaca LocalStorage:", e);
  }
  return null;
}

export function saveBackupToLocalStorage(sessionId, data) {
  try {
    const serialized = JSON.stringify(data);
    localStorage.setItem(`grocery_session_${sessionId}`, serialized);
    localStorage.setItem("grocery_backup", serialized);
  } catch (e) {
    console.error("Gagal menulis ke LocalStorage:", e);
  }
}

export function createDefaultSessionData(sessionId = "sesi-lotte-mart-puri") {
  const today = new Date().toISOString().split("T")[0];
  return {
    sessionId: sessionId,
    storeLocation: "Lotte Mart Grocery - Puri Indah",
    shoppingDate: today,
    walletLimit: 500000, // Rp 500.000 batas standar belanja bulanan anak rantau
    totalSpent: 125500,
    items: [
      {
        id: "item_1",
        name: "Beras Ramos Premium 5kg",
        basePrice: 72500,
        price: 72500,
        disc1: 0,
        disc2: 0,
        discNominal: 0,
        qty: 1,
        unit: "sak",
        category: "Kebutuhan Pokok",
        isChecked: true,
        notes: "Stok makan 3 minggu di kos"
      },
      {
        id: "item_2",
        name: "Telur Ayam Negeri 1kg (Isi 16)",
        basePrice: 28000,
        price: 28000,
        disc1: 0,
        disc2: 0,
        discNominal: 0,
        qty: 1,
        unit: "kg",
        category: "Makanan & Lauk",
        isChecked: true,
        notes: "Lauk protein hemat"
      },
      {
        id: "item_3",
        name: "Sabun Mandi Cair Refill 450ml",
        basePrice: 25000,
        price: 20000, // Diskon 20%
        disc1: 20,
        disc2: 0,
        discNominal: 0,
        qty: 1,
        unit: "pack",
        category: "Mandi & Cuci",
        isChecked: false,
        notes: "Promo potongan 20%"
      }
    ],
    lastUpdated: new Date().toISOString()
  };
}

export function saveCustomFirebaseConfig(configObj) {
  try {
    localStorage.setItem("firebase_custom_config", JSON.stringify(configObj));
    activeFirebaseConfig = configObj;
    initFirebase();
    return true;
  } catch (e) {
    console.error("Gagal simpan konfigurasi Firebase kustom:", e);
    return false;
  }
}
